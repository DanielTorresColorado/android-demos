package com.example.lab08_correccion1;

//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
//import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;

/*
Nota con respecto a Edit y Commit
I noticed, it is important to write difference between commit() and apply() here as well.

commit() return true if value saved successfully otherwise false. It save values to SharedPreferences synchronously.

apply() was added in 2.3 and doesn't return any value either on success or failure.
It saves values to SharedPreferences immediately but starts an asynchronous commit.

 */

public class MainActivity extends AppCompatActivity {
    EditText ed1,ed2,ed3,ed4;
    ListView LV1;
    Button B1, B2;

    public static final String MyPREFERENCES = "MyPrefs" ;
    public static final String Name = "nameKey";
    public static final String Phone = "phoneKey";
    public static final String Email = "emailKey";

    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;


    ArrayList<String> ListaConceptos;
    ArrayAdapter<String> adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ed1=(EditText)findViewById(R.id.editText);
        ed2=(EditText)findViewById(R.id.editText2);
        ed3=(EditText)findViewById(R.id.editText3);
        ed4=(EditText)findViewById(R.id.editText4);
        B1 = findViewById(R.id.button1);
        B2 = findViewById(R.id.button2);
        LV1 = findViewById(R.id.listview1);

        ListaConceptos = new ArrayList<String>();
        // Contenido del archivo listview_item en la carpeta layout:
        /*
        <?xml version="1.0" encoding="utf-8"?>
        <TextView xmlns:android="http://schemas.android.com/apk/res/android"
            android:background="#ffffff"
            android:layout_width="match_parent"
            android:layout_height="match_parent">
        </TextView>
         */
        adapter = new ArrayAdapter<String>(getApplicationContext(),R.layout.listview_item, ListaConceptos);
        LV1.setAdapter(adapter);

        B1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ListaConceptos.add(ed4.getText().toString());
                adapter.notifyDataSetChanged();
                ed4.setText(""); //Lavar el plato despues de tragar desgraciao!
            }
        });

        B2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ListaConceptos.clear();
                adapter.notifyDataSetChanged();

            }
        });
    }

    // Cuando la aplicacion deja el primer plano se ejecuta..
     @Override
    public void onPause() {
        super.onPause();  // Always call the superclass method first
            editor = sharedpreferences.edit();

            String n  = ed1.getText().toString();
            String ph  = ed2.getText().toString();
            String e  = ed3.getText().toString();
            String Listota="";
            if (ListaConceptos.size()>0) Listota = TextUtils.join(",", ListaConceptos);
            else Listota = null;

            editor.putString(Name, n);
            editor.putString(Phone, ph);
            editor.putString(Email, e);
            editor.putString("ListaConceptos",Listota);
            editor.apply();
    }

    // Cuando la aplicación va a primer plano (despues de OnCreate) se ejecuta..
    @Override
    public void onResume () {
        super.onResume();
        sharedpreferences = android.preference.PreferenceManager.getDefaultSharedPreferences(this);
        // SharedPreferences.Editor editor = sharedpreferences.edit();// Esta linea me recuerda a algunos estudiantes..
        String Cadena = sharedpreferences.getString(Name, "");
        if (!Cadena.equalsIgnoreCase("")) {
            ed1.setText(Cadena);
        }
        Cadena = sharedpreferences.getString(Phone, "");
        if (!Cadena.equalsIgnoreCase("")) {
            ed2.setText(Cadena);
        }
        Cadena = sharedpreferences.getString(Email, "");
        if (!Cadena.equalsIgnoreCase("")) {
            ed3.setText(Cadena);
        }

        String serialized =  sharedpreferences.getString("ListaConceptos", null);
        if (serialized!=null) {
            Toast.makeText(getApplicationContext(), serialized, Toast.LENGTH_SHORT).show();
            ListaConceptos = new ArrayList(Arrays.asList(serialized.split(",")));
            //adapter.notifyDataSetChanged(); //Esta Linea deberia ser sufiente, pero NO JALA (Se requieren a fuerza las dos proximas)-
            adapter = new ArrayAdapter<String>(getApplicationContext(),R.layout.listview_item, ListaConceptos);
            LV1.setAdapter(adapter);

        }

        //Toast.makeText(MainActivity.this,"Cargado!!",Toast.LENGTH_LONG).show();


    }



}
