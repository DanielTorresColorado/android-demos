<resources>
    <string name="app_name">MultiplesFormulariosV1</string>

    <string name="hello_world">Hello world!</string>
    <string name="action_settings">Settings</string>
</resources>
