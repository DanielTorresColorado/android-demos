package com.example.mltk_poseestimation;

import java.util.ArrayList;

public class Util {

    public static ArrayList<Data> values = new ArrayList<>();
}
